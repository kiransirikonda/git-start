import logo from './logo.svg';
import './App.css';
import CardsHandle from './componets/cardsfun';

function App() {
  return (
    <div className="App">
      <div>
        <CardsHandle/>
      </div>
    </div>
  );
}

export default App;
