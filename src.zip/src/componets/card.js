import React from "react";
import CardDefault from "../assests/Images/cards/cards2.png";
import { Group, Sprite } from "react-konva";
import gsap from "gsap";
// import cardSound from "../../../../../../assets/audio/Card.mp3";
import Konva from "konva";
Konva.showWarnings = false;

export class Card extends React.Component {
    constructor(props) {
        super(props);
        this.width = window.innerWidth * 0.5;
        this.state = {
            image: null,
            x: this.width - 26,
            y: 50,
            pulldown1:false,
        };
        this.cardStyle = CardDefault;
        // this.cardSound = new Audio(cardSound);
    }

    componentDidMount() {
        this.loadImage(CardDefault);
    }
    componentDidUpdate(prevProps) {
        if (this.cardStyle !== this.props.cardStyle) {
            this.loadImage(this.props.cardStyle);
            this.cardStyle = this.props.cardStyle;
        }
        if (this.props.x != prevProps.x) {
            this.changeCardPosition();
        }

    }
    changeCardPosition() {
        this.imageNode.to({ x: this.props.x, y: this.props.y, duration: 0.5, ease: "Linear" });

    }
    pullDown() {
        this.imageNode.to({ y: this.props.y + 50, x: this.props.x, opacity: 0.35, duration: 0.5, ease: "Linear", visible: false });
    }
    pullUpCards() {
        this.imageNode.to({ y: this.props.y, x: this.props.x, opacity: 0.5, duration: 0.5, ease: "Linear", visible: true });
    }
    pullUp() {
        this.imageNode.to({ y: this.props.y - 10, opacity: 1, duration: 0.5, ease: "Linear" });
    }
    animateCard() {
        // this.cardSound.play();
        // setTimeout(() => {
        // this.setState({ x: this.props.x, y: this.props.y });

        // gsap.to(this.imageNode, { x: this.props.x, y: this.props.y, duration: 0.5, ease: "Linear" });
        this.props.XY({text:this.props.text, x: this.props.x, y: this.props.y})
        this.imageNode.to({ visible: true, duration: 0.05 });
        this.imageNode.to({ x: this.props.x, y: this.props.y, scaleX: this.props.scale, scaleY: this.props.scale, rotation: this.props.angled, duration: 0.5, ease: "EaseInOut" });
        // }, this.props.delay);
    }
    SuffleCard(data) {
        console.log("dataxy",data.x,",",data.y,"      ","props",this.props.x,",",this.props.y)
        gsap.fromTo(this.imageNode,{ x: data.x, y: data.y-10,opacity: 0.5},{ x: this.props.x, y: this.props.y, duration: 0.5, ease: "EaseInOut",opacity:1 })
        // this.imageNode.to({ y: this.props.y - 10, opacity: 1, duration: 0.25, ease: "Linear" });
        // this.imageNode.to({ visible: true, duration: 0.05,x:this.props.x-20 });
        // this.imageNode.to({ x: data.x, y: this.props.y,delay:0.25, duration: 0.75,ease: "Linear" });
        // this.imageNode.to({ x: this.props.x, y: this.props.y, duration: 0.5, ease: "EaseInOut" });
    }
    DrawanimateCard(data) {
        // alert("hi")
        // console.log("dataxy",data.x,",",data.y,"      ","props",this.props.x,",",this.props.y)
        // gsap.to(this.imageNode,{x: this.props.x, y: this.props.y-20,opacity:0})
        var tl = gsap.timeline({});
        tl.fromTo(this.imageNode,{ x: this.props.x, y: this.props.y,opacity: 1,duration:0.5},{ x: this.props.x, y: this.props.y-300, duration: 0.5, ease: "EaseInOut",opacity:0 })
        tl.fromTo(this.imageNode,{ x: this.props.x, y: this.props.y-300,opacity: 0,duration:0.5},{ x: this.props.x, y: this.props.y, duration: 0.5, ease: "EaseInOut",opacity:1 })
        tl.play()
        // this.imageNode.to({ y: this.props.y - 10, opacity: 1, duration: 0.25, ease: "Linear" });
        // this.imageNode.to({ visible: true, duration: 0.05,x:this.props.x-20 });
        // this.imageNode.to({ x: data.x, y: this.props.y,delay:0.25, duration: 0.75,ease: "Linear" });
        // this.imageNode.to({ x: this.props.x, y: this.props.y, duration: 0.5, ease: "EaseInOut" });
    }
    componentWillUnmount() {
        this.image.removeEventListener("load", this.handleLoad);
    }
    loadImage(img) {
        this.image = new window.Image();
        this.image.src = img;
        this.image.addEventListener("load", this.handleLoad);
    }
    handleLoad = () => {
        this.setState({
            image: this.image,
        });
    };
    CardPullUP(e) {
        console.log(e)
        this.setState({pulldown1:!this.state.pulldown1})
        console.log(this.state.pulldown1)
        if(this.state.pulldown1){
            
            this.imageNode.to({ y: this.props.y - 10, opacity: 1, duration: 0.25, ease: "Linear" });
        }else{
            this.imageNode.to({ y: this.props.y, opacity: 1, duration: 0.25, ease: "Linear" });

        }
    }

    render() {
        return (
            <Group>
                <Sprite
                    x={this.width - 26}
                    y={50}
                    // x={this.props.x}
                    // y={this.props.y}
                    ref={(node) => {
                        this.imageNode = node;
                    }}
                    image={this.state.image}
                    // scaleX={this.props.scale}
                    // scaleY={this.props.scale}
                    scaleX={0.15}
                    scaleY={0.15}
                    animations={{
                        cardFrame: this.props.frame,
                    }}
                    animation={"cardFrame"}
                    frameRate={1}
                    frameIndex={0}
                    opacity={this.props.alpha}
                    visible={false}
                    // visible={this.props.show}
                    // rotation={this.props.angled}
                    rotation={0}
                    onClick={(e) => { this.CardPullUP(e) }}
                ></Sprite>
            </Group>
        );
    }
}
