
import React from "react"
import { Group, Layer, Stage } from "react-konva"
import Cards from "./cards";

export default class CardsHandle extends React.Component {
    constructor(props) {
        super(props);

        this.cardsRef = React.createRef()
        this.array=["3d","Jc","7c","7s","7h","8h"]
        this.array1=["7h","Jc","7c","7s","3d","8h"]
        this.array2=["7h","Jc","5c","6s","3d","7h"]
    }
    onDealingCards(data) {
        console.log(data)

        let cnt = data.length;
        for (let i = 0; i < cnt; i++) {
            // var sessionData = JSON.parse(sessionStorage.getItem(`${window.location.hostname}'_sid'`));
            // var encryptDecrypt = new window.EncryptDecrypt(128, 2, "566e4a61fd3220031fa17ebd846c8ec0", "c4c7712d6f62c4f8c40dd2248a029a8a");
            if (data.length > 2) {
                // this.setState({ ratio: 1, hidecardRatio: 30 });
                var b1 = data[i];
                // var b1 = `${encryptDecrypt.decrypt(`${sessionData.sid}`, data.Cards.Card[i]["#text"])}`;
            } else {
                // this.setState({ ratio: 2, hidecardRatio: 0 });
                // var b1 = data.Cards.Card[i]["#text"];
                var b1 = data[i];
            }
            switch (i) {
                case 0:
                    this.cardsRef.current.addCards("cardZero", b1, cnt);
                    break;
                case 1:
                    this.cardsRef.current.addCards("cardOne", b1, cnt);
                    break;
                case 2:
                    this.cardsRef.current.addCards("cardTwo", b1, cnt);
                    break;
                case 3:
                    this.cardsRef.current.addCards("cardThree", b1, cnt);
                    break;
                case 4:
                    this.cardsRef.current.addCards("cardFour", b1, cnt);
                    break;
                case 5:
                    this.cardsRef.current.addCards("cardFive", b1, cnt);
                    break;
                default:
                    break;
            }
            setTimeout(()=>{
                this.onDrawingCards(this.array1)
            },1300)
        }

    }
    onDrawingCards(data){
        console.log(data)

        let cnt = data.length;
        for (let i = 0; i < cnt; i++) {
            // var sessionData = JSON.parse(sessionStorage.getItem(`${window.location.hostname}'_sid'`));
            // var encryptDecrypt = new window.EncryptDecrypt(128, 2, "566e4a61fd3220031fa17ebd846c8ec0", "c4c7712d6f62c4f8c40dd2248a029a8a");
            if (data.length > 2) {
                // this.setState({ ratio: 1, hidecardRatio: 30 });
                var b1 = data[i];
                // var b1 = `${encryptDecrypt.decrypt(`${sessionData.sid}`, data.Cards.Card[i]["#text"])}`;
            } else {
                // this.setState({ ratio: 2, hidecardRatio: 0 });
                // var b1 = data.Cards.Card[i]["#text"];
                var b1 = data[i];
            }
            switch (i) {
                case 0:
                    this.cardsRef.current.SuffleCard("cardZero", b1, cnt);
                    break;
                case 1:
                    this.cardsRef.current.SuffleCard("cardOne", b1, cnt);
                    break;
                case 2:
                    this.cardsRef.current.SuffleCard("cardTwo", b1, cnt);
                    break;
                case 3:
                    this.cardsRef.current.SuffleCard("cardThree", b1, cnt);
                    break;
                case 4:
                    this.cardsRef.current.SuffleCard("cardFour", b1, cnt);
                    break;
                case 5:
                    this.cardsRef.current.SuffleCard("cardFive", b1, cnt);
                    break;
                default:
                    break;
            }
        }
    }
    onDrawingCardsField(data){
        let cnt = data.length;
        for (let i = 0; i < cnt; i++) {
            // var sessionData = JSON.parse(sessionStorage.getItem(`${window.location.hostname}'_sid'`));
            // var encryptDecrypt = new window.EncryptDecrypt(128, 2, "566e4a61fd3220031fa17ebd846c8ec0", "c4c7712d6f62c4f8c40dd2248a029a8a");
            if (data.length > 2) {
                // this.setState({ ratio: 1, hidecardRatio: 30 });
                var b1 = data[i];
                // var b1 = `${encryptDecrypt.decrypt(`${sessionData.sid}`, data.Cards.Card[i]["#text"])}`;
            } else {
                // this.setState({ ratio: 2, hidecardRatio: 0 });
                // var b1 = data.Cards.Card[i]["#text"];
                var b1 = data[i];
            }
            switch (i) {
                case 0:
                    if(this.array1[0]!=b1){

                        this.cardsRef.current.Drawcard("cardZero", b1, cnt);
                    }
                    break;
                case 1:
                    if(this.array1[1]!=b1){
                    this.cardsRef.current.Drawcard("cardOne", b1, cnt);
                    }
                    break;
                case 2:
                    if(this.array1[2]!=b1){
                    this.cardsRef.current.Drawcard("cardTwo", b1, cnt);
                    }
                    break;
                case 3:
                    if(this.array1[3]!=b1){
                    this.cardsRef.current.Drawcard("cardThree", b1, cnt);
                    }
                    break;
                case 4:
                    if(this.array1[4]!=b1){
                    this.cardsRef.current.Drawcard("cardFour", b1, cnt);
                    }
                    break;
                case 5:
                    if(this.array1[5]!=b1){
                    this.cardsRef.current.Drawcard("cardFive", b1, cnt);
                    }
                    break;
                default:
                    break;
            }
            // setTimeout(()=>{
            //     this.onDrawingCards(this.array1)
            // },1300)
        }
 
    }
    
    render() {
        return (
            <>
                <div>
                    <Stage width={window.innerWidth} height={window.innerHeight}>
                        <Layer>
                            <Group>
                                <Cards ref={this.cardsRef} x={(window.innerWidth/2)-20} y={window.innerHeight-180} xPadding={18} scale={0.75} ratioed={1} hidecardPos={30}></Cards>
                            </Group>
                        </Layer>

                    </Stage>
                </div>
                <div>
                    <button style={{position:"absolute",bottom:"100px"}} onClick={() => { this.onDealingCards(this.array) }}>Deal</button>
                    <button style={{position:"absolute",bottom:"80px"}} onClick={() => { this.onDrawingCardsField(this.array2) }}>Draw</button>
                </div>
            </>
        )
    }
}