import React, { Component } from "react";
import { Group } from "react-konva";
// import { Card } from "./card";
import { Card } from "./card";

import CardDefault from "../assests/Images/cards/cards1-(1)-(1).png";

export default class Cards extends Component {
    constructor(props) {
        super(props);
        this.state = {
            cardCount: 2,
            isFront: true,
            cardZeroAlpha: 1,
            cardOneAlpha: 1,
            cardTwoAlpha: 1,
            cardThreeAlpha: 1,
            cardFourAlpha: 1,
            cardFiveAlpha: 1,
            playerCardZero: "Tc",
            playerCardOne: "Ts",
            playerCardTwo: "Td",
            playerCardThree: "Tc",
            playerCardFour: "Tc",
            playerCardFive: "Tc",
            cardStyle: CardDefault,
            // cardBackStyle: [689, 0, 53, 73],
        };
        this.backCard = "default";

        this.mapCards = {
            Ac: [0, 0, 53, 73],
            "2c": [53, 0, 53, 73],
            "3c": [106, 0, 53, 73],
            "4c": [159, 0, 53, 73],
            "5c": [212, 0, 53, 73],
            "6c": [265, 0, 53, 73],
            "7c": [318, 0, 53, 73],
            "8c": [371, 0, 53, 73],
            "9c": [424, 0, 53, 73],
            Tc: [477, 0, 53, 73],
            Jc: [530, 0, 53, 73],
            Qc: [583, 0, 53, 73],
            Kc: [636, 0, 53, 73],

            Ad: [0, 73, 53, 73],
            "2d": [53, 73, 53, 73],
            "3d": [106, 73, 53, 73],
            "4d": [159, 73, 53, 73],
            "5d": [212, 73, 53, 73],
            "6d": [265, 73, 53, 73],
            "7d": [318, 73, 53, 73],
            "8d": [371, 73, 53, 73],
            "9d": [424, 73, 53, 73],
            Td: [477, 73, 53, 73],
            Jd: [530, 73, 53, 73],
            Qd: [583, 73, 53, 73],
            Kd: [636, 73, 53, 73],

            Ah: [0, 146, 53, 73],
            "2h": [53, 146, 53, 73],
            "3h": [106, 146, 53, 73],
            "4h": [159, 146, 53, 73],
            "5h": [212, 146, 53, 73],
            "6h": [265, 146, 53, 73],
            "7h": [318, 146, 53, 73],
            "8h": [371, 146, 53, 73],
            "9h": [424, 146, 53, 73],
            Th: [477, 146, 53, 73],
            Jh: [530, 146, 53, 73],
            Qh: [583, 146, 53, 73],
            Kh: [636, 146, 53, 73],

            As: [0, 219, 53, 73],
            "2s": [53, 219, 53, 73],
            "3s": [106, 219, 53, 73],
            "4s": [159, 219, 53, 73],
            "5s": [212, 219, 53, 73],
            "6s": [265, 219, 53, 73],
            "7s": [318, 219, 53, 73],
            "8s": [371, 219, 53, 73],
            "9s": [424, 219, 53, 73],
            Ts: [477, 219, 53, 73],
            Js: [530, 219, 53, 73],
            Qs: [583, 219, 53, 73],
            Ks: [636, 219, 53, 73],
            xx: [689, 0, 53, 73],
            xx1: [689, 73, 53, 73],
            xx2: [742, 0, 53, 73],
            xx3: [689, 146, 53, 73],
            xx4: [689, 219, 53, 73],
        };
        this.cardsArray = [];
        this.playerCards = [];
        this.tableCards = [];
        this.CardStore = [];
        this.hiddencards = [false, false, false, false, false, false];

        try {
            // this.cardSound = new Audio(cardSound);
        } catch (e) {
            console.log(e);
        }
        this.cardZeroRef = React.createRef();
        this.cardOneRef = React.createRef();
        this.cardTwoRef = React.createRef();
        this.cardThreeRef = React.createRef();
        this.cardFourRef = React.createRef();
        this.cardFiveRef = React.createRef();
        this.groupCards = React.createRef();
    }

    initSounds() {
        try {
            // this.cardSound = new Audio(cardSound);
        } catch (e) {
            console.log(e);
        }
    }
    // setCardStyle(style) {
    //     switch (style.frontCard) {
    //         case "default":
    //             this.setState({ cardStyle: CardDefault });
    //             break;
    //         case "frontCard1":
    //             this.setState({ cardStyle: CardStyleOne });
    //             break;
    //         case "frontCard2":
    //             this.setState({ cardStyle: CardStyleTwo });
    //             break;
    //         case "frontCard3":
    //             this.setState({ cardStyle: CardStyleThree });
    //             break;
    //         case "frontCard4":
    //             this.setState({ cardStyle: CardStyleFour });
    //             break;
    //         default:
    //             this.setState({ cardStyle: CardDefault });
    //             break;
    //     }

    //     this.backCard = style.backCard;
    // }

    addCards(card, text, cnt) {

        if (cnt !== undefined) {
            this.setState({ cardCount: Number(cnt) });
        }
        if (text === "xx") {
            switch (this.backCard) {
                case "default":
                    text = "xx";
                    break;
                case "backcard1":
                    text = "xx1";
                    break;
                case "backcard2":
                    text = "xx2";
                    break;
                case "backcard3":
                    text = "xx3";
                    break;
                case "backcard4":
                    text = "xx4";
                    break;
                default:
                    break;
            }
        }
        if (cnt !== undefined) {
            switch (card) {
                case "cardZero":
                    this.hiddencards[0] = true
                    this.clearCards = setTimeout(() => {
                        this.setState({ playerCardZero: text, cardZeroAlpha: 1 }, () => {
                            try {

                                this.cardZeroRef.current?.animateCard();
                            } catch (e) { console.log(e); }
                        });
                    }, 5);
                    break;
                case "cardOne":
                    this.hiddencards[1] = true
                    this.clearCards = setTimeout(() => {
                        this.setState({ playerCardOne: text, cardOneAlpha: 1 }, () => {
                            this.cardOneRef.current?.animateCard();
                        });
                    }, 200);
                    break;
                case "cardTwo":
                    this.hiddencards[2] = true
                    this.clearCards = setTimeout(() => {
                        this.setState({ playerCardTwo: text, cardTwoAlpha: 1 }, () => {
                            this.cardTwoRef.current?.animateCard();
                        });
                    }, 300);

                    break;
                case "cardThree":
                    this.hiddencards[3] = true
                    this.clearCards = setTimeout(() => {
                        this.setState({ playerCardThree: text, cardThreeAlpha: 1 });
                        this.cardThreeRef.current?.animateCard();
                    }, 450);

                    break;
                case "cardFour":
                    this.hiddencards[4] = true
                    this.clearCards = setTimeout(() => {
                        this.setState({ playerCardFour: text, cardFourAlpha: 1 });
                        this.cardFourRef.current?.animateCard();
                    }, 600);

                    break;
                case "cardFive":
                    this.hiddencards[5] = true
                    this.clearCards = setTimeout(() => {
                        this.setState({ playerCardFive: text, cardFiveAlpha: 1 });
                        this.cardFiveRef.current?.animateCard();
                    }, 750);

                    break;
                default:
                    break;
            }
        }
    }
    SuffleCard(card, text, cnt) {
        // console.log(this.CardStore.indexOf(text))

        // console.log(this.groupCards.current.children)
        // var temp= this.groupCards.current.children[0]
        // this.groupCards.current.children[0]=this.groupCards.current.children[1]
        // this.groupCards.current.children[1]=temp;
        // let array=[2,3,1,0,4]
        // for(let i=0;i<5;i++){

        //     this.groupCards.current.children=this.groupCards.current.children[array[i]]
        // }
        console.log("card", card, "text", text, "cnt", cnt)
        if (cnt !== undefined) {
            this.setState({ cardCount: Number(cnt) });
        }
        if (text === "xx") {
            switch (this.backCard) {
                case "default":
                    text = "xx";
                    break;
                case "backcard1":
                    text = "xx1";
                    break;
                case "backcard2":
                    text = "xx2";
                    break;
                case "backcard3":
                    text = "xx3";
                    break;
                case "backcard4":
                    text = "xx4";
                    break;
                default:
                    break;
            }
        }
        if (cnt !== undefined) {
            switch (card) {
                case "cardZero":
                    setTimeout(() => {
                        this.setState({ playerCardZero: text, cardZeroAlpha: 1 }, () => {
                            try {
                                for (let i = 0; i < this.CardStore.length; i++) {
                                    if (this.CardStore[i].text == text && i != 0) {

                                        this.cardZeroRef.current?.SuffleCard(this.CardStore[i]);
                                        break;
                                    }
                                }
                            } catch (e) { console.log(e); }
                        });
                    }, 5);
                    break;
                case "cardOne":
                    setTimeout(() => {
                        this.setState({ playerCardOne: text, cardOneAlpha: 1 }, () => {
                            for (let i = 0; i < this.CardStore.length; i++) {
                                if (this.CardStore[i].text == text && i != 1) {
                                    this.cardOneRef.current?.SuffleCard(this.CardStore[i]);
                                    break;
                                }
                            }
                        });
                    }, 200);
                    break;
                case "cardTwo":
                    setTimeout(() => {
                        this.setState({ playerCardTwo: text, cardTwoAlpha: 1 }, () => {
                            for (let i = 0; i < this.CardStore.length; i++) {
                                if (this.CardStore[i].text == text && i != 2) {
                                    this.cardTwoRef.current?.SuffleCard(this.CardStore[i]);
                                    break;
                                }
                            }
                        });
                    }, 300);

                    break;
                case "cardThree":
                    setTimeout(() => {
                        this.setState({ playerCardThree: text, cardThreeAlpha: 1 });
                        for (let i = 0; i < this.CardStore.length; i++) {
                            if (this.CardStore[i].text == text && i != 3) {
                                this.cardThreeRef.current?.SuffleCard(this.CardStore[i]);
                                break;
                            }
                        }
                    }, 450);

                    break;
                case "cardFour":
                    setTimeout(() => {
                        this.setState({ playerCardFour: text, cardFourAlpha: 1 });
                        for (let i = 0; i < this.CardStore.length; i++) {
                            if (this.CardStore[i].text == text && i != 4) {
                                this.cardFourRef.current?.SuffleCard(this.CardStore[i]);
                                break;
                            }
                        }
                    }, 600);

                    break;
                case "cardFive":
                    setTimeout(() => {
                        this.setState({ playerCardFive: text, cardFiveAlpha: 1 });
                        for (let i = 0; i < this.CardStore.length; i++) {
                            if (this.CardStore[i].text == text && i != 5) {
                                this.cardFiveRef.current?.SuffleCard();
                                break;
                            }
                        }
                    }, 750);

                    break;
                default:
                    break;
            }
        }
        // var temp=this.cardOneRef;
        // this.cardOneRef=this.cardTwoRef
        // this.cardTwoRef=temp
    }
    Drawcard(card, text, cnt) {

        // console.log(this.CardStore.indexOf(text))

        // console.log(this.groupCards.current.children)
        // var temp= this.groupCards.current.children[0]
        // this.groupCards.current.children[0]=this.groupCards.current.children[1]
        // this.groupCards.current.children[1]=temp;
        // let array=[2,3,1,0,4]
        // for(let i=0;i<5;i++){

        //     this.groupCards.current.children=this.groupCards.current.children[array[i]]
        // }
        console.log("card", card, "text", text, "cnt", cnt)
        if (cnt !== undefined) {
            this.setState({ cardCount: Number(cnt) });
        }
        if (text === "xx") {
            switch (this.backCard) {
                case "default":
                    text = "xx";
                    break;
                case "backcard1":
                    text = "xx1";
                    break;
                case "backcard2":
                    text = "xx2";
                    break;
                case "backcard3":
                    text = "xx3";
                    break;
                case "backcard4":
                    text = "xx4";
                    break;
                default:
                    break;
            }
        }
        if (cnt !== undefined) {
            switch (card) {
                case "cardZero":
                    setTimeout(() => {
                        this.setState({ playerCardZero: text, cardZeroAlpha: 1 }, () => {
                            try {

                                this.cardZeroRef.current?.DrawanimateCard();

                            } catch (e) { console.log(e); }
                        });
                    }, 5);
                    break;
                case "cardOne":
                    setTimeout(() => {
                        this.setState({ playerCardOne: text, cardOneAlpha: 1 }, () => {
                            this.cardOneRef.current?.DrawanimateCard();


                        });
                    }, 200);
                    break;
                case "cardTwo":
                    setTimeout(() => {
                        this.setState({ playerCardTwo: text, cardTwoAlpha: 1 }, () => {
                            this.cardTwoRef.current?.DrawanimateCard();

                        });
                    }, 300);

                    break;
                case "cardThree":
                    setTimeout(() => {
                        this.setState({ playerCardThree: text, cardThreeAlpha: 1 });
                        this.cardThreeRef.current?.DrawanimateCard();

                    }, 450);

                    break;
                case "cardFour":
                    setTimeout(() => {
                        this.setState({ playerCardFour: text, cardFourAlpha: 1 });
                        this.cardFourRef.current?.DrawanimateCard();

                    }, 600);

                    break;
                case "cardFive":
                    setTimeout(() => {
                        this.setState({ playerCardFive: text, cardFiveAlpha: 1 });
                        this.cardFiveRef.current?.DrawanimateCard();
                    }, 750);

                    break;
                default:
                    break;
            }
        }
        // var temp=this.cardOneRef;
        // this.cardOneRef=this.cardTwoRef
        // this.cardTwoRef=temp
    }
    addCards_show(card, text) {
        switch (card) {
            case "cardZero":
                this.setState({ playerCardZero: text, cardZeroAlpha: 1 });
                break;
            case "cardOne":
                this.setState({ playerCardOne: text, cardOneAlpha: 1 });
                break;
            case "cardTwo":
                this.setState({ playerCardTwo: text, cardTwoAlpha: 1 });
                break;
            case "cardThree":
                this.setState({ playerCardThree: text, cardThreeAlpha: 1 });
                break;
            case "cardFour":
                this.setState({ playerCardFour: text, cardFourAlpha: 1 });
                break;
            case "cardFive":
                this.setState({ playerCardFive: text, cardFiveAlpha: 1 });
                break;
            default:
                break;
        }
    }
    showWinningCombination(data) {
        this.setState({
            cardZeroAlpha: 0.35,
            cardOneAlpha: 0.35,
            cardTwoAlpha: 0.35,
            cardThreeAlpha: 0.35,
            cardFourAlpha: 0.35,
            cardFiveAlpha: 0.35,
        });

        try {
            for (let i = 0; i < data.length; i++) {
                switch (Number(data[i].id)) {
                    case 0:
                        this.cardZeroRef.current.pullUp();
                        break;
                    case 1:
                        this.cardOneRef.current.pullUp();
                        break;
                    case 2:
                        this.cardTwoRef.current.pullUp();
                        break;
                    case 3:
                        this.cardThreeRef.current.pullUp();
                        break;
                    case 4:
                        this.cardFourRef.current.pullUp();
                        break;
                    case 5:
                        this.cardFiveRef.current.pullUp();
                        break;
                    default:
                        break;
                }
            }
        } catch (e) { }
    }
    removeCards() {

        this.setState({ cardCount: 0 });
    }

    foldCards() {

        switch (this.state.cardCount) {
            case 2:
                this.cardZeroRef.current.pullDown();
                this.cardOneRef.current.pullDown();
                break;
            case 4:
                this.cardZeroRef.current.pullDown();
                this.cardOneRef.current.pullDown();
                this.cardTwoRef.current.pullDown();
                this.cardThreeRef.current.pullDown();
                break;
            case 5:
                this.cardZeroRef.current.pullDown();
                this.cardOneRef.current.pullDown();
                this.cardTwoRef.current.pullDown();
                this.cardThreeRef.current.pullDown();
                this.cardFourRef.current.pullDown();
                break;
            case 6:
                this.cardZeroRef.current.pullDown();
                this.cardOneRef.current.pullDown();
                this.cardTwoRef.current.pullDown();
                this.cardThreeRef.current.pullDown();
                this.cardFourRef.current.pullDown();
                this.cardFiveRef.current.pullDown();
                break;
            default:
                break;

        }
    }
    showFoldCards() {
        switch (this.state.cardCount) {
            case 2:
                this.cardZeroRef.current.pullUpCards();
                this.cardOneRef.current.pullUpCards();
                break;
            case 4:
                this.cardZeroRef.current.pullUpCards();
                this.cardOneRef.current.pullUpCards();
                this.cardTwoRef.current.pullUpCards();
                this.cardThreeRef.current.pullUpCards();
                break;
            case 5:
                this.cardZeroRef.current.pullUpCards();
                this.cardOneRef.current.pullUpCards();
                this.cardTwoRef.current.pullUpCards();
                this.cardThreeRef.current.pullUpCards();
                this.cardFourRef.current.pullUpCards();
                break;
            case 6:
                this.cardZeroRef.current.pullUpCards();
                this.cardOneRef.current.pullUpCards();
                this.cardTwoRef.current.pullUpCards();
                this.cardThreeRef.current.pullUpCards();
                this.cardFourRef.current.pullUpCards();
                this.cardFiveRef.current.pullUpCards();
                break;
            default:
                break;

        }
    }
    componentWillUnmount() {
        clearTimeout(this.clearCards)
    }
    XY(data) {

        this.CardStore.push(data)
    }
    render() {
        return (
            <Group ref={this.groupCards}>



                <>
                    {this.hiddencards[0] && <Card ref={this.cardZeroRef} x={this.props.x - (this.state.cardCount == 5 ?20:27)} y={this.props.y - (this.state.cardCount == 5 ?6:0)} frame={this.mapCards[this.state.playerCardZero]} scale={this.props.scale} alpha={this.state.cardZeroAlpha} cardStyle={this.state.cardStyle} angled={this.state.cardCount == 5 ? 335 : 330} delay={100} XY={this.XY.bind(this)} text={this.state.playerCardZero}></Card>}
                    {this.hiddencards[1] && <Card ref={this.cardOneRef} x={this.props.x + (this.state.cardCount == 5 ?0:-9.8)} y={this.props.y - (this.state.cardCount == 5 ?18:13)} frame={this.mapCards[this.state.playerCardOne]} scale={this.props.scale} alpha={this.state.cardOneAlpha} cardStyle={this.state.cardStyle} angled={this.state.cardCount == 5 ? 345 : 340} delay={200} XY={this.XY.bind(this)} text={this.state.playerCardOne}></Card>}
                    {this.hiddencards[2] && <Card ref={this.cardTwoRef} x={this.props.x + (this.state.cardCount == 5 ?23:10)} y={this.props.y - (this.state.cardCount == 5 ?25:22)} frame={this.mapCards[this.state.playerCardTwo]} scale={this.props.scale} alpha={this.state.cardTwoAlpha} cardStyle={this.state.cardStyle} angled={this.state.cardCount == 5 ? 355 : 350} delay={400} XY={this.XY.bind(this)} text={this.state.playerCardTwo}></Card>}
                    {this.hiddencards[3] && <Card ref={this.cardThreeRef} x={this.props.x + (this.state.cardCount == 5 ?50:35)} y={this.props.y - (this.state.cardCount == 5 ?27:28)} frame={this.mapCards[this.state.playerCardThree]} scale={this.props.scale} alpha={this.state.cardThreeAlpha} cardStyle={this.state.cardStyle} angled={this.state.cardCount == 5 ? 15 : 10} delay={600} XY={this.XY.bind(this)} text={this.state.playerCardThree}></Card>}
                    {this.hiddencards[4] && <Card ref={this.cardFourRef} x={this.props.x + (this.state.cardCount == 5 ?73:55)} y={this.props.y - (this.state.cardCount == 5 ?22:24)} frame={this.mapCards[this.state.playerCardFour]} scale={this.props.scale} alpha={this.state.cardFourAlpha} cardStyle={this.state.cardStyle} angled={this.state.cardCount == 5 ? 30 : 20} delay={800} XY={this.XY.bind(this)} text={this.state.playerCardFour}></Card>}
                    {this.hiddencards[5] && <Card ref={this.cardFiveRef} x={this.props.x + (this.state.cardCount == 5 ?95:75)} y={this.props.y - (this.state.cardCount == 5 ?16:18)} frame={this.mapCards[this.state.playerCardFive]} scale={this.props.scale} alpha={this.state.cardFiveAlpha} cardStyle={this.state.cardStyle} angled={this.state.cardCount == 5 ? 32 : 32} delay={750} XY={this.XY.bind(this)} text={this.state.playerCardFive}></Card>}
                </>

                {/* {this.state.cardCount == 6 && (
                    <>
                        <Card ref={this.cardZeroRef} x={this.props.x - 27} y={this.props.y + 0} frame={this.mapCards[this.state.playerCardZero]} scale={this.props.scale} alpha={this.state.cardZeroAlpha} cardStyle={this.state.cardStyle} angled={330} delay={100}></Card>
                        <Card ref={this.cardOneRef} x={this.props.x - 9.8} y={this.props.y - 13} frame={this.mapCards[this.state.playerCardOne]} scale={this.props.scale} alpha={this.state.cardOneAlpha} cardStyle={this.state.cardStyle} angled={340} delay={150}></Card>
                        <Card ref={this.cardTwoRef} x={this.props.x + 10} y={this.props.y - 22} frame={this.mapCards[this.state.playerCardTwo]} scale={this.props.scale} alpha={this.state.cardTwoAlpha} cardStyle={this.state.cardStyle} angled={350} delay={300}></Card>
                        <Card ref={this.cardThreeRef} x={this.props.x + 35} y={this.props.y - 28} frame={this.mapCards[this.state.playerCardThree]} scale={this.props.scale} alpha={this.state.cardThreeAlpha} cardStyle={this.state.cardStyle} angled={10} delay={450}></Card>
                        <Card ref={this.cardFourRef} x={this.props.x + 55} y={this.props.y - 24} frame={this.mapCards[this.state.playerCardFour]} scale={this.props.scale} alpha={this.state.cardFourAlpha} cardStyle={this.state.cardStyle} angled={20} delay={600}></Card>
                        <Card ref={this.cardFiveRef} x={this.props.x + 75} y={this.props.y - 18} frame={this.mapCards[this.state.playerCardFive]} scale={this.props.scale} alpha={this.state.cardFiveAlpha} cardStyle={this.state.cardStyle} angled={32} delay={750}></Card>
                    </>
                )} */}
            </Group>
        );
    }
}
